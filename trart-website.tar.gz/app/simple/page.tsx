export default function SimplePage() {
  return <div>Hello World</div>
}
